<?php
        $servidor="localhost";
        $usuario="root";
        $clave="";
        $bbdd="geografia";
?>